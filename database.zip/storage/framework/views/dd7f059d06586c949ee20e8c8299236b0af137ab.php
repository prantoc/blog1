<?php $__env->startSection('content'); ?>
<section class="middle-sec-one mt-3 ml-2">
   <div class="container-fluid">
      <div class="row">
          <?php if($cats->count()): ?>
         <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <!-- <div class="col-md-2"></div> -->
         <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mb-3">
            <div class="hovereffect">
               
               <?php if($c->workfile->img): ?>
               <img class="img-responsive" src="<?php echo e(asset('workfile/feature/'.$c->workfile->img)); ?>" alt="<?php echo e($c->workfile->title); ?>" style="max-height: 180px;">
               <?php else: ?>
               <img class="img-responsive" src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" alt="John Doxe" style="max-height: 180px;">
               <?php endif; ?>
               <div class="overlay">
                  <h2><?php echo e($c->workfile->title); ?></h2>
                  <a class="info" href="<?php echo e(route('work-img-page',$c->workfile->slug)); ?>">See Full Post</a>
                  <?php if(auth()->guard()->guest()): ?>
                  <?php else: ?>
                  <a href="<?php echo e(route($eroute, $c->workfile->id)); ?>" class="btn btn-warning">Edit</a>
                  <?php endif; ?>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php else: ?>
         <span class="btn btn-dark w-md px-5 py-2 mt-2 mb-2 ml-5  d-flex justify-content-center text-white text-blod"><small>No data available !</small></span>
         <?php endif; ?>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.work-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/frontend/single-work.blade.php ENDPATH**/ ?>