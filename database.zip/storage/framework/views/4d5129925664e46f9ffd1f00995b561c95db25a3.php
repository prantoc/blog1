<?php $__env->startSection('styles'); ?>


   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>













   


            <?php if($cats->count()): ?>
    <!--start-->
    <div id="ninja-slider">
            <div class="slider-inner" >
                <ul>

                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($c->file_type == 1): ?>
                    <li>
                        <span class="text-center" style="font-size: 15px; font-weight: bold;">
                   
                    <?php echo $c->details; ?>

              </span>
                    </li>

                     <?php elseif($c->file_type == 2): ?>
                    <li><a class="ns-img" href="<?php echo e(asset('workfile/img/'.$c->file)); ?>"></a>

          

                    </li>
                    <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                
            </div>
            <div id="thumbnail-slider">
                <div class="">
                    <ul>
<?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($ct->file_type == 1): ?>
                        <li>
                            <a class="thumb" href="<?php echo e(asset('assets/img/y.png')); ?>" height="20"></a>
                          
                        </li>
                          <?php elseif($ct->file_type == 2): ?>
                        <li>
                            <a class="thumb" href="<?php echo e(asset('assets/img/i.png')); ?>" height="20"></a>
                            
                        </li>

                            <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </div>
            </div>
       
    </div>

                       <?php else: ?>
         <span class="btn btn-dark w-md px-5 mt-2 mb-2  d-flex justify-content-center text-white text-blod"><small>No data available !</small></span>
         <?php endif; ?>

              
    </div>
    </div>







<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.work-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/frontend/work-img-slider.blade.php ENDPATH**/ ?>