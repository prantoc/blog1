<?php $__env->startSection('content'); ?>
<section class="middle-sec-one mt-3">
   <div class="container-fluid">
      <div class="row">
         <!-- <div class="col-md-2"></div> -->
         <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-6 col-sm-6 mb-5">
            <div class="row text-center justify-content-center">
               <div class="col-md-2 col-sm-6 profile-img">
                  <?php if($t->img): ?>
                  <img src="<?php echo e(asset('img/team/'.$t->img)); ?>" alt="$t->img" style="max-height: 180px;">
                  <?php else: ?>
                  <img src="<?php echo e(asset('assets/img/noimage.jpg')); ?>" alt="$t->name" style="max-height: 180px;">
                  <?php endif; ?>
               </div>
               <div class="col-md-8 col-sm-6">
                  <h2><?php echo e($t->name); ?></h2>
                  <h5><?php echo e($t->position); ?></h5>
                  <h6><?php echo e($t->degree); ?></h6>
               </div>
               <div>
                  <?php if(auth()->guard()->guest()): ?>
                  <?php else: ?>
                  <a href="<?php echo e(route($eroute, $t->id)); ?>" class="btn btn-warning">Edit</a>
                  <?php endif; ?>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.home-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/frontend/team.blade.php ENDPATH**/ ?>