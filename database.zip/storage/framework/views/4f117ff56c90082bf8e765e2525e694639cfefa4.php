  
<?php $__env->startSection('backend-content'); ?>
<!-- Form row -->
<div class="row">
   <div class="col-md-12">
      <div class="card-box">
         <h4 class="m-t-0 header-title">Slider</h4>
         <form method="POST" action="<?php echo e(route($route)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
               <div class="form-group col-md-12">
                  <label class="col-form-label">Slider Image (max:5MB)</label>
                  <input type="file" class="form-control" name="img" value="<?php echo e(old('img')); ?>">
               </div>
            </div>
            <button type="submit" class="btn btn-primary">Add Slider</button>
         </form>
      </div>
      <!-- end card-box -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->
<div class="row">
   <div class="col-lg-12">
      <div class="card-box">
         <h4 class="m-t-0 header-title"><?php echo e($title); ?></h4>
         <table class="table table-bordered mb-0">
            <thead>
               <tr>
                  <th>#</th>
                  <th>Image</th>
                  <th>Position</th>
                  <th>Action</th>
               </tr>
            </thead>
            <tbody>
               <?php $i = 1; ?>
               <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <form method="POST" action="<?php echo e(route($eroute,$slider->id)); ?>" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <tr>
                     <th scope="row"><?php echo e($i); ?></th>
                     <td>
                        <img src="<?php echo e(asset('img/slider/'.$slider->img)); ?>" alt="Image" style="max-width:500px; max-height: 230px;">
                        <label class="col-form-label">Change Image (max:5MB):</label>
                        <input type="file" class="form-control" name="img" value="<?php echo e(old('img')); ?>">
                     </td>
                     <td>
                        <input type="text" class="form-control" name="position" value="<?php echo e($slider->position); ?>">
                     </td>
                     <td>
                        <button type="submit" class=" btn btn-primary mb-5">Update</button> 
                        <a data-href="<?php echo e(route($droute,$slider->id)); ?>" class="cat-delete btn btn-danger" style="color: #fff;"> Delete</a>
                     </td>
                  </tr>
               </form>
               <?php $i++; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
      </div>
      <!-- end card-box -->
   </div>
   <!-- end col -->
</div>
<!-- end row -->    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
   for(var els = document.getElementsByClassName("cat-delete"), i = els.length; i--;){
       els[i].href = 'javascript:void(0);';
       els[i].onclick = (function(el){
           return function(){
               swal({
                 title: 'Are you sure?',
                 text: "You won't be able to revert this!",
                 type: 'warning',
                 showCancelButton: true,
                 confirmButtonColor: '#3085d6',
                 cancelButtonColor: '#d33',
                 confirmButtonText: 'Yes, delete it!'
               }).then((result) => {
                 if (result.value) {
                   window.location.href = el.getAttribute('data-href');
                   swal({
                     title: 'Deleting!',
                      text: 'Your file is being deleted.',
                     timer: 2000,
                     onOpen: () => {
                       swal.showLoading()
                       timerInterval = setInterval(() => {
                         swal.getContent().querySelector('strong')
                           .textContent = swal.getTimerLeft()
                       }, 100)
                     },
                     onClose: () => {
                       clearInterval(timerInterval)
                     }
                 }
   
                   )
                 }
               })
               
           };
       })(els[i]);
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/backend/slider.blade.php ENDPATH**/ ?>