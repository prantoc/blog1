  <?php $__env->startSection('content'); ?>
    <section class="middle-sec-one mt-3 ml-2">
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <div class="col-md-2"></div> -->
               <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 mb-3">
                    <div class="hovereffect">
                        
                        <?php if($c->workfile->img): ?>
                              <img class="img-responsive" src="<?php echo e(asset('workfile/feature/'.$c->workfile->img)); ?>" alt="<?php echo e($c->workfile->title); ?>" style="max-height: 180px;">
                              <?php else: ?>
                            <img class="img-responsive" src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" alt="John Doxe" style="max-height: 180px;">
                            <?php endif; ?>
             
                        <div class="overlay">
                            <h2><?php echo e($c->title); ?></h2>
                            <a class="info" href="">See Full Post</a>
                        </div>
                    </div>
                </div>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
           
            </div>
        </div>
        
    </section>
















  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.work-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/frontend/single-work-img.blade.php ENDPATH**/ ?>