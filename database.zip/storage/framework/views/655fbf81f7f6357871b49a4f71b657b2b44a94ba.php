<?php $__env->startSection('content'); ?>
<div id="carouselExampleIndicators" class="carousel slide mt-3" data-ride="carousel" data-interval="false">

   <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
       <?php if($cats->count()): ?>
      <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($c->file_type == 1): ?>

      <div class="carousel-item text-dark text-center   <?php echo e($key == 0 ? 'active' : ''); ?>"  style="font-size: 25px; font-weight: bold;">
            <?php echo $c->details; ?>

      </div>

      <?php elseif($c->file_type == 2): ?>
      
      <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>" style="background-image: url('<?php echo e(asset('workfile/img/'.$c->file)); ?>')">
      </div>

        <?php elseif($c->file_type == 3): ?>
      
      <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">

         <video controls autoplay muted loop id="myVideo" width="880" class="ml-5 justify-content-center text-center">
           <source src="<?php echo e(asset('workfile/video/'.$c->file)); ?>" type="video/mp4" >
         </video>
      </div>

      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
   <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
   </a>
   <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
   </a>


</div>
 <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($c->file_type == 1): ?>
 <span class="s-icon carousel-inner"><i class="fab fa-tumblr-square ml-3 <?php echo e($key == 0 ? 'active' : ''); ?>"></i></span>

<?php elseif($c->file_type == 2): ?>
<span class="s-icon"><i class="fas fa-image ml-3 "></i></span>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
<a href="<?php echo e(route($eroute, $c->id)); ?>" class="btn btn-warning ml-3">Edit</a>
<?php endif; ?>

        <?php else: ?>
         <span class="btn btn-dark w-md px-5 mt-2 mb-2  d-flex justify-content-center text-white text-blod"><small>No data available !</small></span>
         <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.work-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ampps\www\blog1\resources\views/frontend/work-img-slider.blade.php ENDPATH**/ ?>