    <footer class="footer">
        <div class="container-fluid">
            <nav class="nav footer-active mt-4 mg">
                <a class="nav-link " href="<?php echo e(route('contact')); ?>"><i class="fas fa-envelope-square"></i></a>
                <a class="nav-link" href="<?php echo e(route('contact')); ?>"><i class="fas fa-phone-square"></i></a>
                <a class="nav-link" href="https://mail.google.com"><i class="fas fa-at"></i></a>
                <a class="nav-link" href="#"><i class="fab fa-facebook-square"></i></a>
                <a class="nav-link" href="#"><i class="fab fa-linkedin"></i></a>
            </nav>

            <span class="copyright">©2015 prachee sthapati . Developed by<a class="nav-link d-inline" href="https://mybdhost.com/" target="_blank">Mybdhost</a></span>
        </div>
    </footer>


    <?php /**PATH E:\Ampps\www\blog1\resources\views/layouts/frontend/footer.blade.php ENDPATH**/ ?>