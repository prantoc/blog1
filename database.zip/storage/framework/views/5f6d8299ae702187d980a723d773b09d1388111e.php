<?php $__env->startSection('content'); ?>
<section class="middle-sec-one mt-3 ml-2">
   <div class="container-fluid">
      <div class="row">
         <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 mb-3">
            <div class="hovereffect">
               <?php if($work->img): ?>
               <img class="img-responsive" src="<?php echo e(asset('work/feature/'.$work->img)); ?>" alt="$work->img" >
               <?php else: ?>
               <img class="img-responsive" src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" alt="John Doe" >
               <?php endif; ?>
               <div class="overlay">
                  <h2><?php echo e($work->title); ?></h2>
                  <a class="info" href="<?php echo e(route('all-work-single',$work->slug)); ?>">See Full Post</a>
                  <?php if(auth()->guard()->guest()): ?>
                  <?php else: ?>
                  <a href="<?php echo e(route($eroute, $work->id)); ?>" class="btn btn-warning">Edit</a>
                  <?php endif; ?>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.work-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ampps\www\blog1\resources\views/frontend/work.blade.php ENDPATH**/ ?>