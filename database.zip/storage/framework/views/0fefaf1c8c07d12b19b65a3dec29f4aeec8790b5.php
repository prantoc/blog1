<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH K:\Ampps\www\Laravel\blog1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>