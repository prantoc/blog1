  
<?php $__env->startSection('backend-content'); ?>
<div class="col-lg-8">
   <div class="card-box">
      <h4 class="header-title m-t-0"><?php echo e($title); ?></h4>
      <form method="POST" action="<?php echo e(route($route,$team->id)); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <div class="form-group">
            <label for="name">Name<span class="text-danger">*</span></label>
            <input type="text" name="name" parsley-trigger="change" required="" placeholder="Jon Dev" class="form-control" id="userName" value="<?php echo e($team->name); ?>">
         </div>
         <div class="form-group">
            <label for="position">Position<span class="text-danger">*</span></label>
            <input type="text" name="position" parsley-trigger="change" required="" placeholder="principal architect" class="form-control" id="emailAddress" value="<?php echo e($team->position); ?>">
         </div>
         <div class="form-group">
            <label for="degree">Degree<span class="text-danger">*</span></label>
            <input type="text" name="degree" parsley-trigger="change" required="" placeholder="b. arch. (buet) 2001 m. arch. (buet) 2019" class="form-control" id="emailAddress" value="<?php echo e($team->degree); ?>">
         </div>
         <div class="form-group">
            <label for="img">Image<span class="text-danger">*</span></label>
               <?php if($team->img): ?>
                  <img src="<?php echo e(asset('img/team/'.$team->img)); ?>" alt="" style="max-height: 180px;">
               <?php else: ?>
                  <img src="<?php echo e(asset('assets/img/noimage.jpg')); ?>" alt="" style="max-height: 180px;">
               <?php endif; ?>
            <img src="<?php echo e(asset('upload/'.$team->img)); ?>" alt="" height="100" width="180">
            <input type="file" name="img" value="<?php echo e($team->img); ?>" class="form-control" id="inputZip">
         </div>
         <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
            Update
            </button>
         </div>
      </form>
   </div>
   <!-- end card-box -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ampps\www\blog1\resources\views/backend/edit-team.blade.php ENDPATH**/ ?>