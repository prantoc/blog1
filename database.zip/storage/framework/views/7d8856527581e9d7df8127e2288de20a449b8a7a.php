 
<?php $__env->startSection('backend-content'); ?>
<div class="row">
   <div class="col-lg-12">
      <div class="card-box">
         <h4 class="m-t-0 header-title"><?php echo e($title); ?></h4>
         <table class="table table-sm mb-0 table table-bordered">
            <thead>
               <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Description</th>
                  <?php if($hasCats): ?>
                  <th>Img</th>
                  <?php endif; ?>
                  <th class="text-center" colspan="2"> Action</th>
               </tr>
            </thead>
            <tbody>
               <?php if($news->count()): ?>
               <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <th scope="row"><?php echo e($new->id); ?></th>
                  <td><?php echo e($new->title); ?></td>
                  <td><?php echo str_limit(strip_tags($new->details,20)); ?></td>
                  <?php if($hasCats): ?>
                  <td>
                     <?php if($new->img): ?>
                     <img src="<?php echo e(asset('img/client/'.$new->img)); ?>" alt="$new->img" height="100" width="180">
                     <?php else: ?>
                     <img src="<?php echo e(asset('assets/img/noimage.jpg')); ?>" alt="$new->name" height="100" width="180">
                     <?php endif; ?>
                  </td>
                  <?php endif; ?>
                  <td><a href="<?php echo e(route($editroute,$new->id)); ?>" class="btn btn-primary" style="margin-left: 26px;">Edit </a></td>
                  <td><a data-href="<?php echo e(route($droute,$new->id)); ?>" class="btn btn-danger cat-delete" style="margin-left: 26px;"> Delete </a></td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
         <span class="btn btn-dark w-md px-5 mt-2 mb-2  d-flex justify-content-center text-white text-blod"><small>No data available !</small></span>
         <?php endif; ?>
            </tbody>
         </table>
         <?php echo e($news); ?>

      </div>
      <!-- end card-box -->
   </div>
   <!-- end col -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
   for(var els = document.getElementsByClassName("cat-delete"), i = els.length; i--;){
       els[i].href = 'javascript:void(0);';
       els[i].onclick = (function(el){
           return function(){
               swal({
                 title: 'Are you sure?',
                 text: "You won't be able to revert this!",
                 type: 'warning',
                 showCancelButton: true,
                 confirmButtonColor: '#3085d6',
                 cancelButtonColor: '#d33',
                 confirmButtonText: 'Yes, delete it!'
               }).then((result) => {
                 if (result.value) {
                   window.location.href = el.getAttribute('data-href');
                   swal({
                     title: 'Deleting!',
                      text: 'Your file is being deleted.',
                     timer: 5000,
                     onOpen: () => {
                       swal.showLoading()
                       timerInterval = setInterval(() => {
                         swal.getContent().querySelector('strong')
                           .textContent = swal.getTimerLeft()
                       }, 200)
                     },
                     onClose: () => {
                       clearInterval(timerInterval)
                     }
                 }
   
                   )
                 }
               })
   
           };
       })(els[i]);
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/backend/all-pages.blade.php ENDPATH**/ ?>