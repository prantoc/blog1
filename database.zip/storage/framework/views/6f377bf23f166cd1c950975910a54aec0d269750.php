<?php $__env->startSection('content'); ?>
<!-- Login -->
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-12">
    <!--  ==================================SESSION MESSAGES==================================  -->
        <?php if(session()->has('message')): ?>
            <div class="alert alert-<?php echo session()->get('type'); ?> alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo session()->get('message'); ?>

            </div>
        <?php endif; ?>
    <!--  ==================================SESSION MESSAGES==================================  -->


    <!--  ==================================VALIDATION ERRORS==================================  -->
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <?php echo $error; ?>

                </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
    <!--  ==================================SESSION MESSAGES==================================  -->
                    </div>
                    <div class="col-12">

                        <div class="wrapper-page">
                            <div class="account-pages">
                                <div class="account-box">

                                    <!-- Logo box-->
                                    <div class="account-logo-box">
                                        <h2 class="text-uppercase text-center">
                                            <a href="<?php echo e(route('login')); ?>" class="text-success">
                                                <span><img src="<?php echo e(asset('assets/img/prachee-logo.png')); ?> " alt="" height="28"></span>
                                            </a>
                                        </h2>
                                    </div>

                                    <div class="account-content">
                                         <?php if(isset($url)): ?>
                                        <form method="POST" action='<?php echo e(url("login/$url")); ?>' aria-label="<?php echo e(__('Login')); ?>">
                                        <?php else: ?>
                                        <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                                        <?php endif; ?>
                                        <?php echo csrf_field(); ?>
                                            <div class="form-group mb-3">
                                                <?php if(isset($url)): ?>
                                                <label for="username" class="font-weight-medium">Username/email</label>
                                               <input id="username" type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                                                <?php if($errors->has('username')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                                <?php else: ?>
                                                <label for="email" class="font-weight-medium">Email</label>
                                               <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                                <?php if($errors->has('email')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            </div>

                                            <div class="form-group mb-3">
                                                
                                                <label for="password" class="font-weight-medium">Password</label>
                                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                                <?php if($errors->has('password')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="form-group mb-3">
                                                <div class="checkbox checkbox-info">
                                                    <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                    <label for="remember">
                                                        Remember me
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="form-group row text-center">
                                                <div class="col-12">
                                                    <button class="btn btn-block btn-success waves-effect waves-light" type="submit">Sign In</button>
                                                </div>
                                            </div>
                                        </form> <!-- end form -->

                                        <!-- end row-->
                                    </div> <!-- end account-content -->

                                </div> <!-- end account-box -->
                            </div>
                            <!-- end account-page-->
                        </div>
                        <!-- end wrapper-page -->

                    </div> <!-- end col -->
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/auth/login.blade.php ENDPATH**/ ?>