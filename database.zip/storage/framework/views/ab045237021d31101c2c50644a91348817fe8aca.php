  <?php $__env->startSection('content'); ?>
    <section class="middle-sec-one mt-3">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-7 col-sm-12 paragraph">
                    <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                            <a href="<?php echo e(route($eroute, $page->id)); ?>" class="btn btn-warning float-right">Edit</a>
                    <?php endif; ?>
                    <p>
                       <?php echo $page->details; ?>

                    </p>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.home-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/frontend/about.blade.php ENDPATH**/ ?>