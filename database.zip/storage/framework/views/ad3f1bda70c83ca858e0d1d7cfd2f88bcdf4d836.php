<header class="header">
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="<?php echo e(route ('home')); ?>"><img src="<?php echo e(asset('assets/img/prachee-logo.png')); ?>" alt="prachee"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
         <ul class="navbar-nav menu-pos">
            <li class="nav-item">
               <a style="position: absolute;left: 89%;" class="nav-link d-flex justify-content-end " href="<?php echo e(route ('home')); ?>">home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
               <a class="nav-link d-flex justify-content-end" href="<?php echo e(route ('work')); ?>">work</a>
               <ul class="list-group list-group-horizontal navbar-nav mydropdown worksub-pos">
                  <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item  <?php if($work->slug == request()->route('slug') ): ?> active <?php endif; ?>">
                     <a class="nav-link" href="<?php echo e(route('all-work-single',$work->slug)); ?>"><?php echo e($work->title); ?></a>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
            </li>
         </ul>
      </div>
   </nav>
</header><?php /**PATH E:\Ampps\www\blog1\resources\views/layouts/frontend/headerwork.blade.php ENDPATH**/ ?>