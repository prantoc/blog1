<?php $__env->startSection('content'); ?>
<section class="middle-sec-one mt-3">
   <div class="container-fluid">
      <div class="row">
         <!-- <div class="col-md-2"></div> -->
         <div class="col-md-12 col-sm-12 mb-5">
          
                   
            <div class="card-body" style="max-height: 550px;">
               <?php $url = urlencode($adms->address) ; $url = htmlentities($url); ?>
               <iframe width="1300" height="450" frameborder="0" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=<?php echo e($url); ?>&t=&z=15&ie=UTF8&iwloc=&output=embed">
               </iframe>
            </div>
           
         </div>
         <div class="col-md-3"></div>
         <div class="contact-detail text-center ml-5 font-weight-blod col-md-6">
            <!-- <a class="navbar-brand" href="index.html"><img src="img/prachee-logo.png" alt="prachee"></a> -->
            <div class="address">
               <p  class="font-weight-bold "> <i class="fas fa-envelope-square"></i> room F5, 3rd floor 113, lake circus 
                  kalabagan 
                  dhaka-1205
               </p>
            </div>
            <div class="phone">
               <p  class="font-weight-bold">
                  <i class="fas fa-phone-square"></i> 88 02 9112912
               </p>
            </div>
            <div class="email">
               <p  class="font-weight-bold">
                  <i class="fa fa-at"></i>  mail@pracheesthapati.com
               </p>
            </div>
         </div>
         <div class="col-md-3"></div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.home-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/frontend/contact.blade.php ENDPATH**/ ?>