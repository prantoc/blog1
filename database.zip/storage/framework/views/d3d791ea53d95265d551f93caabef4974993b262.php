<?php $__env->startSection('content'); ?>
<section class="middle-sec-one mt-2">
   <div class="container">
      <?php if(auth()->guard()->guest()): ?>
      <?php else: ?>
      <a href="<?php echo e(route($eroute, $pageimg->id)); ?>" class="btn btn-warning float-right">Edit</a>
      <?php endif; ?>
      <div class="row">
         <div class="col-lg-7 col-md-12 col-sm-12 mt-5">
            <img src="<?php echo e(asset('img/page/'.$pageimg->img)); ?>" alt="" width="468" height="356">
         </div>
         <div class="col-lg-5 col-md-12 col-sm-12">
            <div class="paragraph">
               <p class="mt-3">
                  <?php echo $pageimg->details; ?>

               </p>
            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.home-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/frontend/principle.blade.php ENDPATH**/ ?>