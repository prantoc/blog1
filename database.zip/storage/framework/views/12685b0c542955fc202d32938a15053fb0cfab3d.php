<header class="header">
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="<?php echo e(route ('home')); ?>"><img src="<?php echo e(asset('assets/img/prachee-logo.png')); ?>" alt="prachee"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
         <ul class="navbar-nav menu-pos">
            <li class="nav-item">
               <a style="position: absolute;left: 89%;" class="nav-link d-flex justify-content-end " href="<?php echo e(route ('home')); ?>">home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
               <a class="nav-link d-flex justify-content-end" href="<?php echo e(route ('work')); ?>">work</a>
               <ul class="list-group list-group-horizontal navbar-nav mydropdown worksub-pos">
                  <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="dropdown nav-item  <?php if($work->slug == request()->route('slug') ): ?> active <?php endif; ?>">
                     <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button"  aria-haspopup="true" aria-expanded="false" href="<?php echo e(route('all-work-single',$work->slug)); ?>"><?php echo e($work->title); ?></a>


                          <?php if(!$work->workfiles->isEmpty()): ?>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <?php $__empty_1 = true; $__currentLoopData = $work->workfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a class="dropdown-item" href="#"><?php echo e($wf->workfile->title); ?></a>
                                
                                
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                              </div>   
                            
                          <?php endif; ?>

                          <?php endif; ?>

                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
            </li>
         </ul>
      </div>
   </nav>
</header><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/layouts/frontend/headerwork.blade.php ENDPATH**/ ?>