<?php echo e($slot); ?>

<?php /**PATH K:\Ampps\www\Laravel\blog1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>