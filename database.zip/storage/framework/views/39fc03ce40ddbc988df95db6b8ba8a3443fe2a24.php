<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <title>prachee sthapati</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="manifest" href="site.webmanifest">
    
    <!-- Place favicon.ico in the root directory -->
    <!-- Booststrap & fontawsome Css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/normalize.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">

     <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">

    <meta name="theme-color" content="#fafafa">
</head>

<body>

        <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        
        <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       

        

    <script src="<?php echo e(asset('assets/js/vendor/modernizr-3.7.1.min.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script>
        window.jQuery || document.write('<script src="js/vendor/jquery-3.4.1.min.js"><\/script>')
    </script>
    <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.js')); ?>"></script>
    <script>
        
        if(!function_exists('is_active_menu')){

    function is_active_menu($url){

        return \Route::is($url) ? 'active' : '';
    }

}
    </script>

</body>

</html><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/layouts/frontend/home-design.blade.php ENDPATH**/ ?>