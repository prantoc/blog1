  
<?php $__env->startSection('backend-content'); ?>


   <!-- Register -->
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-12">

                        <div class="wrapper-page">
                            <div class="account-pages">
                                <div class="account-box">

                                    <!-- Logo box-->
                         

                                    <div class="account-content">
                                        <form class="form-horizontal" method="POST" action="<?php echo e(route($uroute, $admin->id)); ?>">
                                                 <?php echo csrf_field(); ?>
                                            <div class="form-group mb-3">
                                         
                                                 <label for="name" class="font-weight-medium"><?php echo e(__('Name')); ?></label>
                                             
                                                      
                                <input id="name"  placeholder="Michael Zenaty" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($admin->name); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                           
                                            </div>

                                            <div class="form-group mb-3">
                                                <label for="email" class="font-weight-medium">Email address</label>
                                            
                                                <input id="email" placeholder="john@deo.com" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e($admin->email); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>


                                            <div class="form-group mb-3">
                                                <label for="password" class="font-weight-medium">Set Password</label>
                                              
                                                 <input placeholder="Enter your password" id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"  autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>


                                    <div class="form-group mb-3">
                                        
                                                <label for="password-confirm" class="font-weight-medium"><?php echo e(__('Confirm Password')); ?></label>
                                              
                                                  <input placeholder="Enter your password" id="password-confirm" type="password" class="form-control" name="password_confirmation"  autocomplete="new-password">
                                            </div>

                                       

                                            <div class="form-group">
                                                <button class="btn btn-block btn-success waves-effect waves-light" type="submit">Update </button>
                                            </div>
                                        </form> <!-- end form -->

                                   

                                    </div> <!-- end account-content -->

                                </div> <!-- end account-box -->
                            </div>
                            <!-- end account-page-->
                        </div>
                        <!-- end wrapper-page -->

                    </div> <!-- end col -->
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- END HOME --> 
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ampps\www\blog1\resources\views/backend/edit-admin.blade.php ENDPATH**/ ?>