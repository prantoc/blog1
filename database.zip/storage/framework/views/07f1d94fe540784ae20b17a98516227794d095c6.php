  
<?php $__env->startSection('backend-content'); ?>
<div class="row">
   <div class="col-lg-12">
      <div class="card-box">
         <h4 class="m-t-0 header-title"><?php echo e($title); ?></h4>
         <table class="table table-bordered mb-0">
            <thead>
               <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Username</th>
                  <th>Reg. Date</th>
                  <th class="text-center" colspan="2"> Action</th>
               </tr>
            </thead>
            <tbody>
               <?php if($admins->count()): ?>
               <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <th scope="row"><?php echo e($admin->id); ?></th>
                  <td><?php echo e($admin->name); ?></td>
                  <td><?php echo e($admin->email); ?></td>
                  <td><?php echo e($admin->name); ?></td>
                  <td><?php echo e($admin->created_at); ?></td>
                  <td><a href="<?php echo e(route($eroute,$admin->id)); ?>" class="btn btn-primary" style="margin-left: 26px;">Edit </a></td>
                  <td><a data-href="<?php echo e(route($droute,$admin->id)); ?>" class="btn btn-danger cat-delete text-white" style="margin-left: 26px;"> Delete </a></td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
         <span class="btn btn-dark w-md px-5 mt-2 mb-2  d-flex justify-content-center text-white text-blod"><small>No data available !</small></span>
         <?php endif; ?>
            </tbody>
         </table>
         <?php echo e($admins); ?>

      </div>
      <!-- end card-box -->
   </div>
   <!-- end col -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
   for(var els = document.getElementsByClassName("cat-delete"), i = els.length; i--;){
       els[i].href = 'javascript:void(0);';
       els[i].onclick = (function(el){
           return function(){
               swal({
                 title: 'Are you sure?',
                 text: "If you delete this admin then all of the data which added this admin is deleted & You won't be able to revert this!",
                 type: 'warning',
                 showCancelButton: true,
                 confirmButtonColor: '#3085d6',
                 cancelButtonColor: '#d33',
                 confirmButtonText: 'Yes, delete it!'
               }).then((result) => {
                 if (result.value) {
                   window.location.href = el.getAttribute('data-href');
                   swal({
                     title: 'Deleting!',
                      text: 'Your file is being deleted.',
                     timer: 2000,
                     onOpen: () => {
                       swal.showLoading()
                       timerInterval = setInterval(() => {
                         swal.getContent().querySelector('strong')
                           .textContent = swal.getTimerLeft()
                       }, 100)
                     },
                     onClose: () => {
                       clearInterval(timerInterval)
                     }
                 }
   
                   )
                 }
               })
               
           };
       })(els[i]);
   }
   
   
   
   $('#datatable1').DataTable({
       keys: true
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/backend/all-admin.blade.php ENDPATH**/ ?>