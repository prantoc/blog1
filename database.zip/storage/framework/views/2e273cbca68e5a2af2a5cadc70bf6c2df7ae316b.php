  <?php $__env->startSection('content'); ?>


    <section class="middle-sec-one mt-3">
        <div class="container-fluid">
            <div class="row text-center">
                <!-- <div class="col-md-2"></div> -->
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-6 mb-5">
                                       <?php if($c->img): ?>
  <img src="<?php echo e(asset('img/client/'.$c->img)); ?>" alt="$c->img" style="max-height: 180px;">
  <?php else: ?>
<img src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" alt="John Doe" style="max-height: 180px;">
<?php endif; ?>
  <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                        <a href="<?php echo e(route($eroute, $c->id)); ?>" class="btn btn-warning">Edit</a>
                         <?php endif; ?>
                </div>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
              
            </div>

        </div>
        
    </section>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.home-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ampps\www\blog1\resources\views/frontend/clients.blade.php ENDPATH**/ ?>