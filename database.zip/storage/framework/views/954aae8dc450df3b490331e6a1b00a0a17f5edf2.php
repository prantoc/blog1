  <?php $__env->startSection('content'); ?>


           <div class="row">

                        <div class="col-12">
                        <!--  ==================================SESSION MESSAGES==================================  -->
                            <?php if(session()->has('message')): ?>
                                <div class="alert alert-<?php echo session()->get('type'); ?> alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php echo session()->get('message'); ?>

                                </div>
                            <?php endif; ?>
                        <!--  ==================================SESSION MESSAGES==================================  -->


                        <!--  ==================================VALIDATION ERRORS==================================  -->
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="alert alert-danger alert-dismissable">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <?php echo $error; ?>

                                    </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        <!--  ==================================SESSION MESSAGES==================================  -->
                        </div>
                    </div>

    <section class="middle-sec-one mt-3 mb-5">
        <div class="container">
            <div class="row">
                <!-- <div class="col-md-2"></div> -->
                <div class="col-md-5 col-sm-6 mb-5">
                  <form method="POST" action="<?php echo e(route('post-apply')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Name</label>
                        <input type="text" class="form-control" id="exampleFormControlInput1" name="name">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Email address</label>
                        <input type="email" class="form-control" id="exampleFormControlInput1" name="email">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Subject</label>
                        <input type="text" class="form-control" id="exampleFormControlInput1" name="subject">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Upload your CV</label>
                        <input type="file" class="form-control bg-secondary" id="exampleFormControlInput1" name="up_cv">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlInput1">Upload your Portfolio</label>
                        <input type="file" class="form-control bg-secondary" id="exampleFormControlInput1" name="up_protfolio">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlTextarea1">Message</label>
                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="mgs"></textarea>
                      </div>
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
                <div class="col-md-7 col-sm-6 mb-5">
                    <p>
                        <?php echo $page->details; ?>

                    </p>

                      <?php if(auth()->guard()->guest()): ?>
                        <?php else: ?>
                        <a href="<?php echo e(route($eroute, $page->id)); ?>" class="btn btn-warning">Edit</a>
                         <?php endif; ?>
                </div>
              
            </div>

        </div>
        
    </section>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.home-design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Ampps\www\blog1\resources\views/frontend/career.blade.php ENDPATH**/ ?>