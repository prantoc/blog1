<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>prachee sthapati</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">

        <!-- jvectormap -->
        <link href="<?php echo e(asset('assets/backend/libs/jqvmap/jqvmap.min.css')); ?>" rel="stylesheet" />

        <!-- DataTables -->
        <link href="<?php echo e(asset('assets/backend/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('assets/backend/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>


        <!-- DataTables -->
        <link href="<?php echo e(asset('assets/backend/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('assets/backend/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('assets/backend/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('assets/backend/libs/datatables.net-select-bs4/css/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">

        <!-- Icons css -->
        <link href="<?php echo e(asset('assets/backend/libs/@mdi/font/css/materialdesignicons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/backend/libs/dripicons/webfont/webfont.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/backend/libs/simple-line-icons/css/simple-line-icons.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <!-- build:css -->
        <link href="<?php echo e(asset('assets/backend/css/app.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- endbuild -->

                 <!-- Sweet Alert css -->
        <link href="<?php echo e(asset('assets/backend/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php echo $__env->yieldContent('styles'); ?>
<?php echo $__env->yieldContent('top-styles'); ?>

    </head>

    <body>


        <?php echo $__env->make('layouts.backend.backend-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <!-- Page Content Start -->
        <div class="content-page">
            <div class="content">
                <div class="container-fluid">

                    <!-- Page title box -->
                      <div class="page-title-box">
                            <ol class="breadcrumb float-right">
                                <li class="breadcrumb-item"><a href="javascript:void(0);">Prachee Shapati Dashboard</a></li>
                                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                            </ol>
                            <h4 class="page-title">Dashboard</h4>
                        </div>
                    <!-- End page title box -->

                    <div class="row">
                        <div class="col-12">
                        <!--  ==================================SESSION MESSAGES==================================  -->
                            <?php if(session()->has('message')): ?>
                                <div class="alert alert-<?php echo session()->get('type'); ?> alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php echo session()->get('message'); ?>

                                </div>
                            <?php endif; ?>
                        <!--  ==================================SESSION MESSAGES==================================  -->


                        <!--  ==================================VALIDATION ERRORS==================================  -->
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="alert alert-danger alert-dismissable">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <?php echo $error; ?>

                                    </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        <!--  ==================================SESSION MESSAGES==================================  -->
                        </div>
                    </div>

        <?php echo $__env->yieldContent('backend-content'); ?>

                </div> <!-- end container-fluid-->
            </div> <!-- end contant-->
        </div>

        <?php echo $__env->make('layouts.backend.backend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>


        </div>
        <!-- End #wrapper -->

        <!-- jQuery  -->
        <script src="<?php echo e(asset('assets/backend/libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/metismenu/metisMenu.min.js')); ?>"></script>

        <!-- KNOB JS -->
        <script src="<?php echo e(asset('assets/backend/libs/jquery-knob/jquery.knob.min.js')); ?>"></script>
        <!-- Chart JS -->
        <script src="<?php echo e(asset('assets/backend/libs/chart.js/Chart.bundle.min.js')); ?>"></script>

        <!-- Jvector map -->
        <script src="<?php echo e(asset('assets/backend/libs/jqvmap/jquery.vmap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>

        <!-- Datatable js -->
        <script src="<?php echo e(asset('assets/backend/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>

           <!-- Sweet Alert Js  -->
        <script src="<?php echo e(asset('assets/backend/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/js/jquery.sweet-alert.init.js')); ?>"></script>

        <!-- Dashboard Init JS -->
        <script src="<?php echo e(asset('assets/backend/js/jquery.dashboard.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('assets/backend/js/jquery.core.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/backend/js/jquery.app.js')); ?>"></script>
        <script>
            $(document).ready(function() {
                // Default Datatable
                $('#datatable').DataTable({
                    "pageLength": 5,
                    "searching": false,
                    "lengthChange": false
                });
            } );
        </script>

           <script>
            <?php if(session()->has('message')): ?>
                swal({
                title: "<?php echo session()->get('title'); ?>",
                text: "<?php echo session()->get('message'); ?>",
                type: "<?php echo session()->get('type'); ?>",
                confirmButtonText: "OK"
            });
                <?php echo e(Session::forget('message')); ?>

            <?php endif; ?>



        </script>


         <?php echo $__env->yieldContent('scripts'); ?>

    </body>
</html><?php /**PATH K:\Ampps\www\Laravel\blog1\resources\views/layouts/backend/dashboard.blade.php ENDPATH**/ ?>