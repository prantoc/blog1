
<!-- Footer -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                 <span class="copyright">©2015 prachee sthapati . Developed by<a class="nav-link d-inline" href="https://mybdhost.com/" target="_blank">Mybdhost</a></span>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->