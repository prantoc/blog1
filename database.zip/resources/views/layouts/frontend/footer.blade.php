    <footer class="footer fixed-bottom">
        <div class="container-fluid">
            <nav class="nav footer-active mt-4 mg">
                <a class="nav-link " href="{{route('contact')}}"><i class="fas fa-envelope-square"></i></a>
                <a class="nav-link" href="{{route('contact')}}"><i class="fas fa-phone-square"></i></a>
                <a class="nav-link" href="https://mail.google.com"><i class="fas fa-at"></i></a>
                <a class="nav-link" href="#"><i class="fab fa-facebook-square"></i></a>
                <a class="nav-link" href="#"><i class="fab fa-linkedin"></i></a>
            </nav>

            <span class="copyright">©2015 prachee sthapati . Developed by<a class=" d-inline" href="https://mybdhost.com/" target="_blank" style="color: #F7941E; font-weight: 600;">  Mybdhost</a></span>
        </div>
    </footer>


    